// Question #1: Array Manipulation
const arr = [1, 2, 43, 5, 6, 87, 4, 8, 4, 7];
document.getElementById("output").innerHTML = arr.join(',');
arr.unshift(50);
document.getElementById("outpt").innerHTML = arr.join();
arr.pop();
document.getElementById("out").innerHTML = arr;
arr.push(10);
document.getElementById("ot").innerHTML = arr;
arr.shift();
document.getElementById("ot1").innerHTML = arr;
arr.reverse();
document.getElementById("rvr").innerHTML = arr;

// Question #2: Object Manipulation
const Car = {
    Make: "Toyota",
    Model: "Corolla",
    year: "2020",
    price: 25000,
    displayInfo: function() {
        return `This is a ${this.year} ${this.Make} ${this.Model} priced at $${this.price}.`;
    }
};
document.getElementById("info").innerHTML = Car.displayInfo();
function update(Car) {
    Car.price -= Car.price * 0.15;
    return Car.price;
}
document.getElementById("updt").innerHTML = update(Car);
document.getElementById("dsp").innerHTML = Car.displayInfo();

// Question #3: JSON Parsing and Modification
function prs(str) {
    const js = JSON.parse(str);
    return js;
}
const nam = '{"Title":"JavaScript: The Good Parts","author":"Douglas Crockford","pages":176,"Published":2008}';
let book = prs(nam);
document.getElementById("prs").innerHTML = JSON.stringify(book);
book.pages += 50;
const upBok = JSON.stringify(book);
document.getElementById("upPages").innerHTML = upBok;

// Question #4: Debugging with Console
function calculateTotalPrice(price, taxRate) {
    console.log("Before Fix:");
    console.log("Price: " + price);
    console.log("Tax Rate (String): " + taxRate);

    taxRate = parseFloat(taxRate); // Convert taxRate to number
    let total = price * taxRate;

    console.log("After Fix:");
    console.log("Price: " + price);
    console.log("Tax Rate (Number): " + taxRate);
    console.log("Total Price: " + total);
}
calculateTotalPrice(100, "0.2");

// Question #5: Error Handling with Try-Catch-Finally
function calculateDiscountedPrice(originalPrice, discountPercentage) {
    if (discountPercentage < 0 || discountPercentage > 100) {
        throw new Error("Invalid discount percentage!");
    }
    let discountedPrice = originalPrice - (originalPrice * (discountPercentage / 100));
    return discountedPrice;
}

try {
    let price = calculateDiscountedPrice(1000, 110); // Invalid discount
    console.log("Discounted Price: $" + price);
} catch (error) {
    console.log("Error: " + error.message);
} finally {
    console.log("Discount calculation completed.");
}
